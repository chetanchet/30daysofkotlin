package com.example.mytdk

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Toast

class ScollerAct : AppCompatActivity() {

    lateinit var n:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scoller)
        n=findViewById(R.id.net)
    }

    fun clicker(v:View)=Toast.makeText(applicationContext,"Hello "+n.text,Toast.LENGTH_SHORT).show()

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.my2,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.xact1->{
                startActivity(Intent(this,MainActivity::class.java))
                true
            }
            else->super.onOptionsItemSelected(item)
        }
    }
}