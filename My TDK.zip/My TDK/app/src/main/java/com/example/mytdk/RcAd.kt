package com.example.mytdk

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RcAd(var items: ArrayList<Ptdk>) : RecyclerView.Adapter<RcAd.Vh>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
        return Vh(LayoutInflater.from(parent.context).inflate(R.layout.myc, parent, false))
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: Vh, position: Int) {
        val ob = items[position]
        holder.bind(ob)
    }

    class Vh(vi: View) : RecyclerView.ViewHolder(vi) {
        var mn: TextView = vi.findViewById(R.id.xmn)
        var my: TextView = vi.findViewById(R.id.xmy)
        fun bind(o: Ptdk) {
            mn.text = o.name
            my.text = o.year.toString()
        }
    }
}