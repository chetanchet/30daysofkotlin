package com.example.mytdk

data class Ptdk(val name:String,val year:Int)