package com.example.mytdk

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mytdk.databinding.ActivityMainBinding
import timber.log.Timber

class MainActivity : AppCompatActivity() {

    lateinit var bnd:ActivityMainBinding

    lateinit var fet:TextView
    lateinit var let:TextView
    lateinit var rv:RecyclerView
    var mlist=ArrayList<Ptdk>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bnd=DataBindingUtil.setContentView(this,R.layout.activity_main)

        fet=bnd.xfet
        let=bnd.xlet
        rv=bnd.xrv

        rv.layoutManager=LinearLayoutManager(this)
        rv.adapter=RcAd(mlist)
    }

    fun adder(v:View){
        mlist.add(Ptdk(fet.text.toString(),let.text.toString().toInt()))
        rv.adapter?.notifyDataSetChanged()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.mymenu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.xact2-> {
                startActivity(Intent(applicationContext,ScollerAct::class.java))
                true
            }
            else-> super.onOptionsItemSelected(item)
        }
    }

    override fun onStart() {
        super.onStart()
        Timber.i("Started")
    }

    override fun onResume() {
        super.onResume()
        Timber.i("Resumed")
    }

    override fun onRestart() {
        super.onRestart()
        Timber.i("Restarted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Timber.i("Destroyed")
    }

    override fun onStop() {
        super.onStop()
        Timber.i("Stopped")
    }

    override fun onPause() {
        super.onPause()
        Timber.i("Paused")
    }

}